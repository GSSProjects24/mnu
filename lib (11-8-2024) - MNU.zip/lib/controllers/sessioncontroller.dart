import 'package:get/get.dart';


import '../models/sessionModel.dart';

class SessionController extends GetxController {
  final session = Session().obs;

  // RxBool follow = true.obs;

  // followRequest() {
  //   follow = follow.value;
  // }

  // loadData(){
  //
  //   session.update((val) {
  //
  //     val?.loadSession();
  //
  //
  //   });
  //
  //
  // }
}

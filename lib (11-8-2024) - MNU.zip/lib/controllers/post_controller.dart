import 'package:get/get.dart';
import 'package:flutter/foundation.dart';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class PostController extends GetxController {
  List<Uint8List> memoryImage = <Uint8List>[].obs;
  List<Uint8List> memoryVideo = <Uint8List>[].obs;
  List<String> images = <String>[].obs;
  List<String> videos = <String>[].obs;
  List<File> files = <File>[].obs;
  List<File> videoFiles = <File>[].obs;
  List<String?> urls = <String?>[].obs;

  Future<void> addFileFromCamera() async {
    PickedFile? result = (await ImagePicker.platform.pickImage(source: ImageSource.camera));
    if (result != null) {
      files.add(File(result.path));
      images = await convertFilesToBase64();

      await File(result.path).readAsBytes().then((value) => memoryImage.add(value));
    }
  }

  Future<void> addImageFromGalley() async {
    PickedFile? result = (await ImagePicker.platform.pickImage(source: ImageSource.gallery));
    if (result != null) {
      files.add(File(result.path));
      images = await convertFilesToBase64();

      await File(result.path).readAsBytes().then((value) => memoryImage.add(value));
    }
  }

  Future<void> addVideoFromCamera() async {
    PickedFile? result = (await ImagePicker.platform.pickVideo(source: ImageSource.camera));
    if (result != null) {
      videoFiles.add(File(result.path));
      videos = await convertVideosToBase64().whenComplete(() => print('*****************************done**************************************'));

      await File(result.path).readAsBytes().then((value) => memoryVideo.add(value));
    }
  }

  Future<void> addVideoFromGallery() async {
    PickedFile? result = (await ImagePicker.platform.pickVideo(source: ImageSource.gallery));
    if (result != null) {
      videoFiles.add(File(result.path));
      videos = await convertVideosToBase64().whenComplete(() => print('*****************************done**************************************'));

      await File(result.path).readAsBytes().then((value) => memoryVideo.add(value));
    }
  }

  Future<void> addprofileFromCamera() async {
    files = [];
    memoryImage = [];

    PickedFile? result = (await ImagePicker.platform.pickImage(source: ImageSource.camera));
    if (result != null) {
      files.add(File(result.path));
      images = await convertFilesToBase64();

      await File(result.path).readAsBytes().then((value) => memoryImage.add(value));
    }
  }

  Future<void> addFiles() async {
    List<PickedFile> result = (await ImagePicker.platform.pickMultiImage()) ?? [];
    if (result != null) {
      files.addAll(result.map((e) => File(e.path)));
      images = await convertFilesToBase64();

      for (var file in result) {
        await File(file.path).readAsBytes().then((value) => memoryImage.add(value));
      }
    }
  }

  Future<void> addFile() async {
    files = [];
    memoryImage = [];
    PickedFile? result = await ImagePicker.platform.pickImage(source: ImageSource.gallery);
    if (result != null) {
      files.add(File(result.path));
      images = await convertFilesToBase64();

      await File(files[0].path).readAsBytes().then((value) => memoryImage.add(value));
    }
  }

  removeFile(File e) {
    files.remove(e);
  }

  Future<List<String>> convertFilesToBase64() {
    List<Future<String>> futures = [];
    for (var file in files) {
      futures.add(convertFiletoBase64(file));
    }

    return Future.wait(futures);
  }

  Future<List<String>> convertVideosToBase64() {
    List<Future<String>> futures = [];
    for (var file in videoFiles) {
      futures.add(convertFiletoBase64(file));
    }

    return Future.wait(futures);
  }

  Future<String> convertFiletoBase64(File file) {
    return file.readAsBytes().then((Uint8List uint8list) {
      return base64Encode(uint8list);
    });
  }

  Future<void> LoadNetworkImage(List<String?> urls) async {
    for (var String in urls) {
      var data = await networkImageToBase64(String!);
      images.add(data!);
      print('loop');
      var data2 = await networkImageTouint(String!);
      memoryImage.add(data2!);
    }
  }

  Future<String?> networkImageToBase64(String imageUrl) async {
    http.Response response = await http.get(Uri.parse(imageUrl));
    print('test');
    final bytes = response?.bodyBytes;
    return (bytes != null ? base64Encode(bytes) : null);
  }

  Future<Uint8List?> networkImageTouint(String imageUrl) async {
    http.Response response = await http.get(Uri.parse(imageUrl));

    print('test');
    return response?.bodyBytes;
  }
}

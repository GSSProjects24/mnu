import 'dart:convert';

import 'package:get/get.dart';

import '../models/pendngrequestmodel.dart';
import 'package:http/http.dart' as http;

class PendingRequestController extends GetxController{

  final pendingList= PendingRequestModel().obs;










}
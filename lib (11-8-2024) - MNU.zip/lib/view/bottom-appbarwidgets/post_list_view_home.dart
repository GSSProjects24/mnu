import 'dart:convert';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:like_button/like_button.dart';
import 'package:mnu_app/view/bottom-appbarwidgets/notifictions_page.dart';

import 'package:photo_view/photo_view.dart';

import 'package:readmore/readmore.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../controllers/list_of_post_controller.dart';
import '../../controllers/sessioncontroller.dart';
import '../../main.dart';
import '../../models/notifications_model.dart';
import '../../models/sessionModel.dart';
import '../../models/single_post_view.dart';
import '../../theme/myfonts.dart';
import 'package:http/http.dart' as http;

import 'package:mnu_app/view/bottom-appbarwidgets/single_post_view.dart'
    as video;
import '../homePage.dart';
import '../profile/create-post-page.dart';
import '../profile/friend_requestlist.dart';
import '../profile/friends-profile.dart';
import '../profile/suggestionprofile.dart';
import '../widgets/custom_progress_indicator.dart';
import 'package:carousel_indicator/carousel_indicator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:badges/badges.dart' as badges;
import 'package:badges/badges.dart' as badge;

class HomeListPostPage extends StatefulWidget {
  const HomeListPostPage(
      {Key? key,
      required this.title,
      required this.apiurl,
      this.isMember,
      this.isHq,
      this.isHome})
      : super(key: key);
  final String title;
  final String apiurl;
  final bool? isMember;
  final bool? isHq;
  final bool? isHome;

  @override
  State<HomeListPostPage> createState() => _HomeListPostPageState();
}

class _HomeListPostPageState extends State<HomeListPostPage> {
  Future<void> _launchInBrowser(Uri url) async {
    if (!await launchUrl(
      url,
      mode: LaunchMode.externalApplication,
    )) {
      throw Exception('Could not launch $url');
    }
  }

  Session c = Session();
  bool isLoading = false;
  //flag to check if all items loaded
  bool isAllLoaded = false;
  late int totalreports;
  int limit = 20;
  bool snapshotLoading = true;
  ScrollController scrollcontroller = ScrollController();

  Future<Map<String, dynamic>> deleteMyPost(String id) async {
    var body = {
      "user_id":
          Get.find<SessionController>().session.value.data?.userId.toString(),
      "post_id": id,
      "comment": ''
    };
    print(Get.find<SessionController>().session.value.data?.userId);
    final response = await http.put(
        Uri.parse('http://mnuapi.graspsoftwaresolutions.com/api_post_delete'),
        body: body);

    if (response.statusCode == 200) {
      print(response.body);
      return jsonDecode(response.body);
    } else {
      print(response.body);
      throw Exception('Failed to load data');
    }
  }

  Future<SinglePostViewModel> viewCountPostGetFromSinglePost(String id) async {
    var body = {
      "user_id":
          Get.find<SessionController>().session.value.data?.userId.toString(),
      "post_id": id,
    };
    final response = await http.post(
        Uri.parse(
            'http://mnuapi.graspsoftwaresolutions.com/api_single_post_view'),
        body: body);
    if (response.statusCode == 200) {
      print(response.body);

      return SinglePostViewModel.fromJson(jsonDecode(response.body));
    } else {
      print(response.body);
      throw Exception('Failed to load data');
    }
  }

  @override
  void initState() {
    // TODO: implement initState

    // postlist = loadPost();
    super.initState();
  }

  Future<Map<String, dynamic>> postViewCount(String id) async {
    var body = {
      "user_id":
          Get.find<SessionController>().session.value.data?.userId.toString(),
      "post_id": id,
    };
    print(Get.find<SessionController>().session.value.data?.userId);
    final response = await http.put(
        Uri.parse('http://mnuapi.graspsoftwaresolutions.com/api_post_view_add'),
        body: body);

    if (response.statusCode == 200) {
      print(response.body);
      return jsonDecode(response.body);
    } else {
      print(response.body);
      throw Exception('Failed to load data');
    }
  }

  Future<NotificationsModel> loadNotifications() async {
    var body = {
      "user_id":
          Get.find<SessionController>().session.value.data?.userId.toString() ??
              '',
      "page": "1",
      "limit": "50"
    };
    final response = await http.post(
      Uri.parse(
          'http://mnuapi.graspsoftwaresolutions.com/api_push_notification'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(body),
    );

    if (response.statusCode == 200) {
      // print(response.body);
      return NotificationsModel.fromJson(jsonDecode(response.body));
    } else {
      // print(response.body);
      throw Exception('Failed to load data');
    }
  }

  Future block(String followerUserId) async {
    print('block request start');
    var body = {
      "follower_user_id": followerUserId,
      "user_id":
          Get.find<SessionController>().session.value.data?.userId.toString(),
    };
    print(
        'user id ${Get.find<SessionController>().session.value.data?.userId} follower user id ${followerUserId}');
    print('api url http://mnuapi.graspsoftwaresolutions.com/api_block_request');
    final response = await http.post(
        Uri.parse('http://mnuapi.graspsoftwaresolutions.com/api_block_request'),
        body: body);
    print('${body}bbbbbbbbbbbbbbbbb');

    if (response.statusCode == 200) {
      print(response.body);
      return jsonDecode(response.body);
    } else {
      print(response.body);
      throw Exception('Failed to load data');
    }
  }

  @override
  Widget build(BuildContext context) {
    final uri = Uri.tryParse('');
    return Scaffold(
      appBar: AppBar(
        leading: widget.isHome == true
            ? Padding(
                padding: const EdgeInsets.all(8.0),
                child: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Image.asset('assets/MNU-Logo.png',
                      height: Get.height * 0.08, width: Get.width * 0.08),
                ),
              )
            : BackButton(
                onPressed: () async {
                  const CustomProgressIndicator();
                  await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const HomePage()));
                  setState(() {});
                },
              ),
        title: Text(
          widget.title,
          style: getText(context)
              .titleLarge
              ?.copyWith(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        actions: [
          badges.Badge(
            badgeStyle: badges.BadgeStyle(badgeColor: clrschm.primary),
            position: badges.BadgePosition.topStart(top: -19),
            badgeContent: FutureBuilder<NotificationsModel>(
              future: loadNotifications(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Text('');
                } else if (snapshot.data!.data!.status == false) {
                  return badge.Badge(
                    showBadge: false,
                    badgeStyle: badge.BadgeStyle(
                      badgeColor: clrschm.primary,
                      borderRadius: BorderRadius.circular(0.2),
                    ),
                    badgeContent: Text(
                      "",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  );
                } else {
                  print(
                      'fffffffffffffffffffffff${snapshot.data!.data!.notifcationDetails!.totalReports!.noticationCount}');
                  return badge.Badge(
                    showBadge: snapshot.data!.data!.notifcationDetails!
                                .totalReports!.unseenCount ==
                            0
                        ? false
                        : true,
                    badgeStyle: badge.BadgeStyle(
                      badgeColor: clrschm.primary,
                      borderRadius: BorderRadius.circular(0.2),
                    ),
                    badgeContent: Text(
                      snapshot.data!.data!.notifcationDetails!.totalReports!
                          .unseenCount
                          .toString(),
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  );
                }
              },
            ),
            child: IconButton(
              onPressed: () {
                Get.to(() => const NotificationsPage(
                      user_ids: '',
                    ));
              },
              icon: const Icon(
                Icons.notifications,
                color: Colors.white,
              ),
            ),
          ),
          widget.isHq == true
              ? Text("")
              : IconButton(
                  onPressed: () async {
                    // Get.to(() => PostCreatePage(
                    //       isEdit: false,
                    //     ));

                    showDialog(
                        context: context,
                        builder: (context) {
                          return SizedBox(
                              width: Get.width,
                              height: Get.height,
                              child: PostCreatePage(
                                isEdit: false,
                              ));
                        }).then((value) async {
                      Get.find<ListOfPostController>().post.value =
                          await Get.find<ListOfPostController>()
                              .loadPost('', limit, widget.apiurl);
                    });
                  },
                  icon: Icon(Icons.add_box_rounded))
        ],
      ),
      body: GetX<ListOfPostController>(
          init: ListOfPostController(),
          initState: (value) async {
            value.controller?.post.value =
                (await value.controller?.loadPost('', limit, widget.apiurl))!;
          },
          builder: ((snapshot) {
            final posts = snapshot.post.value.data?.postDetails?.posts;

            if (posts == null || posts.isEmpty) {
              if (widget.isMember == true) {
                return const Center(
                  child: Text('No posts found'),
                );
              } else {
                // If not a member, show "No posts"
                return const Center(
                  child: CustomProgressIndicator(),
                );
              }
              // return Center(
              //   child: Text("No posts found"),
              // );
            }

            totalreports = snapshot
                    .post.value.data?.postDetails?.totalReports?.postCount ??
                0;

            return ListView.builder(
              controller: scrollcontroller
                ..addListener(() {
                  if (scrollcontroller.position.pixels ==
                      scrollcontroller.position.maxScrollExtent) {
                    setState(() {
                      isLoading = true;
                      limit += 15;
                    });

                    Future.delayed(Duration(microseconds: 100), () async {
                      if (snapshotLoading) {
                        showLoading(context);
                        setState(() async {
                          snapshotLoading = false;

                          snapshot.post.value = (await snapshot
                              .loadPost('', limit, widget.apiurl)
                              .whenComplete(() {
                            Navigator.pop(context);
                            snapshotLoading = true;
                          }))!;

                          isLoading = false;
                        });
                      } else {
                        setState(() {
                          isAllLoaded = true;
                          isLoading = false;
                        });
                      }
                    });
                  }
                }),
              itemCount:
                  snapshot.post.value?.data?.postDetails?.posts?.length ?? 0,
              itemBuilder: (BuildContext context, int index) {
                return Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: Card(
                    color: Colors.white,
                    surfaceTintColor: Colors.white,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ListTile(
                          dense: true,
                          onTap: () {
                            Get.to(() => FriendsProfile(
                                  memberNo: snapshot
                                      .post
                                      .value
                                      .data!
                                      .postDetails!
                                      .posts![index]!
                                      .userDetails!
                                      .userId
                                      .toString(),
                                  profileImage: snapshot
                                          .post
                                          .value
                                          .data!
                                          .postDetails!
                                          .posts![index]!
                                          .userDetails
                                          ?.profileImg ??
                                      '',
                                  name: '',
                                ));
                          },
                          leading: CircleAvatar(
                            radius: 23,
                            backgroundImage: const NetworkImage(
                                'http://upcwapi.graspsoftwaresolutions.com/public/images/user.png'),
                            foregroundImage: NetworkImage(snapshot
                                    .post
                                    .value
                                    .data!
                                    .postDetails!
                                    .posts![index]!
                                    .userDetails!
                                    .profileImg!
                                    .isEmpty
                                ? ''
                                : snapshot.post.value.data!.postDetails!
                                    .posts![index]!.userDetails!.profileImg!),
                          ),
                          title: Text(
                            snapshot.post.value?.data?.postDetails
                                    ?.posts![index]?.userDetails!.name
                                    .toString() ??
                                '',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          subtitle: Flex(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            direction: Axis.vertical,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                snapshot.post.value?.data?.postDetails
                                        ?.posts![index]?.date
                                        .toString() ??
                                    '',
                                style: TextStyle(fontSize: 10),
                              ),
                              Text(
                                snapshot.post.value?.data?.postDetails
                                            ?.posts![index]?.title ==
                                        null
                                    ? ''
                                    : snapshot.post.value.data?.postDetails
                                            ?.posts![index]?.title
                                            .toString() ??
                                        "",
                                style: TextStyle(
                                    fontSize: 15, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          trailing: widget.isMember == true
                              ? PopupMenuButton(
                                  elevation: 10,
                                  itemBuilder: (context) {
                                    return [
                                      PopupMenuItem(
                                          child: TextButton(
                                        onPressed: () {
                                          Get.to(() => PostCreatePage(
                                                isEdit: true,
                                                urls: snapshot
                                                    .post
                                                    .value
                                                    ?.data
                                                    ?.postDetails
                                                    ?.posts![index]
                                                    ?.image,
                                                content: snapshot
                                                    .post
                                                    .value
                                                    ?.data
                                                    ?.postDetails
                                                    ?.posts![index]
                                                    ?.content,
                                                title: snapshot
                                                    .post
                                                    .value
                                                    ?.data
                                                    ?.postDetails
                                                    ?.posts![index]
                                                    ?.title,
                                                postId: snapshot
                                                    .post
                                                    .value
                                                    ?.data
                                                    ?.postDetails
                                                    ?.posts![index]
                                                    ?.postId
                                                    .toString(),
                                              ));
                                        },
                                        child: Text('Edit  '),
                                      )),
                                      PopupMenuItem(
                                          child: TextButton(
                                        onPressed: () {
                                          showDialog(
                                              context: context,
                                              builder: (context) {
                                                return AlertDialog(
                                                  title: Text(
                                                      'Are you sure to delete this post'),
                                                  actions: [
                                                    TextButton(
                                                        onPressed: () {
                                                          Navigator.pop(
                                                              context);
                                                          Navigator.pop(
                                                              context);
                                                          Navigator.pop(
                                                              context);
                                                        },
                                                        child: Text('cancel')),
                                                    TextButton(
                                                        onPressed: () async {
                                                          showLoading(context);
                                                          deleteMyPost(snapshot
                                                                      .post
                                                                      .value
                                                                      ?.data
                                                                      ?.postDetails
                                                                      ?.posts![
                                                                          index]
                                                                      ?.postId
                                                                      .toString() ??
                                                                  '')
                                                              .then(
                                                                  (value) async {
                                                            if (value["data"]
                                                                ["status"]) {
                                                              Get.find<ListOfPostController>()
                                                                      .post
                                                                      .value =
                                                                  (await snapshot
                                                                      .loadPost(
                                                                          '',
                                                                          limit,
                                                                          widget
                                                                              .apiurl))!;

                                                              Navigator.pop(
                                                                  context);
                                                              Navigator.pop(
                                                                  context);
                                                              Navigator.pop(
                                                                  context);
                                                            }
                                                          });
                                                        },
                                                        child: Text('Delete'))
                                                  ],
                                                );
                                              });
                                        },
                                        child: Text('Delete'),
                                      ))
                                    ];
                                  },
                                )
                              : (snapshot.post.value.data!.postDetails!
                                          .posts![index]?.userDetails!.userId
                                          .toString()) ==
                                      Get.find<SessionController>()
                                          .session
                                          .value
                                          .data
                                          ?.userId
                                          .toString()
                                  ? Text('')
                                  : PopupMenuButton(
                                      itemBuilder: (itemBuilder) => [
                                            PopupMenuItem(
                                                child: TextButton(
                                              onPressed: () {
                                                showDialog(
                                                    context: context,
                                                    builder: (context) {
                                                      return AlertDialog(
                                                        title: Text(
                                                          'Are you sure to block this User',
                                                          style: TextStyle(
                                                              fontSize: 16),
                                                        ),
                                                        actions: [
                                                          TextButton(
                                                              onPressed: () {
                                                                Navigator.pop(
                                                                    context);
                                                                Navigator.pop(
                                                                    context);
                                                              },
                                                              child: Text(
                                                                  'cancel')),
                                                          TextButton(
                                                              onPressed:
                                                                  () async {
                                                                print(
                                                                    'block user url ${widget.apiurl} limit ${limit}, ');
                                                                showLoading(
                                                                    context); // Show loading spinner
                                                                var response =
                                                                    await block(
                                                                  snapshot
                                                                      .post
                                                                      .value
                                                                      .data!
                                                                      .postDetails!
                                                                      .posts![
                                                                          index]!
                                                                      .userDetails!
                                                                      .userId
                                                                      .toString(),
                                                                );

                                                                // Check if the response has a successful status
                                                                if (response[
                                                                            "data"]
                                                                        [
                                                                        "status"] ==
                                                                    true) {
                                                                  Get.find<ListOfPostController>()
                                                                          .post
                                                                          .value =
                                                                      await snapshot
                                                                          .loadPost(
                                                                    '',
                                                                    limit,
                                                                    widget
                                                                        .apiurl,
                                                                  )!;

                                                                  Navigator.pop(
                                                                      context); // Close the loading dialog
                                                                  Navigator.pop(
                                                                      context);
                                                                  Navigator.pop(
                                                                      context);
                                                                } else {
                                                                  Navigator.pop(
                                                                      context);
                                                                  Navigator.pop(
                                                                      context);
                                                                  Navigator.pop(
                                                                      context);

                                                                  Get.snackbar(
                                                                    "Failed",
                                                                    response["data"]
                                                                            [
                                                                            "error_msg"] ??
                                                                        "Something went wrong. Please contact administrator.",
                                                                    snackPosition:
                                                                        SnackPosition
                                                                            .BOTTOM,
                                                                    duration: Duration(
                                                                        seconds:
                                                                            3),
                                                                  );
                                                                }
                                                              },
                                                              // onPressed:
                                                              //     () async {
                                                              //   showLoading(
                                                              //       context);
                                                              //   block(snapshot
                                                              //           .post
                                                              //           .value
                                                              //           .data!
                                                              //           .postDetails!
                                                              //           .posts![
                                                              //               index]!
                                                              //           .userDetails!
                                                              //           .userId
                                                              //           .toString())
                                                              //       .then(
                                                              //           (value) async {
                                                              //     if (value[
                                                              //             "data"]
                                                              //         [
                                                              //         "status"]) {
                                                              //       Get.find<ListOfPostController>()
                                                              //               .post
                                                              //               .value =
                                                              //           (await snapshot.loadPost(
                                                              //               '',
                                                              //               limit,
                                                              //               widget.apiurl))!;
                                                              //
                                                              //       Navigator.pop(
                                                              //           context);
                                                              //       Navigator.pop(
                                                              //           context);
                                                              //       Navigator.pop(
                                                              //           context);
                                                              //     }
                                                              //   });
                                                              // },
                                                              child:
                                                                  Text('Block'))
                                                        ],
                                                      );
                                                    });
                                              },
                                              child: Row(
                                                children: [
                                                  Icon(Icons.person),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text('Block user'),
                                                ],
                                              ),
                                            )),
                                            PopupMenuItem(
                                                child: TextButton(
                                              onPressed: () {
                                                showDialog(
                                                    context: context,
                                                    builder: (context) {
                                                      return AlertDialog(
                                                        title: Text(
                                                            'Report this content',
                                                            style: TextStyle(
                                                                fontSize: 16)),
                                                        actions: [
                                                          TextButton(
                                                              onPressed: () {
                                                                Navigator.pop(
                                                                    context);
                                                                Navigator.pop(
                                                                    context);
                                                              },
                                                              child: Text(
                                                                  'cancel')),
                                                          TextButton(
                                                              onPressed:
                                                                  () async {
                                                                showLoading(
                                                                    context); // Show loading spinner
                                                                var response =
                                                                    await block(
                                                                  snapshot
                                                                      .post
                                                                      .value
                                                                      .data!
                                                                      .postDetails!
                                                                      .posts![
                                                                          index]!
                                                                      .userDetails!
                                                                      .userId
                                                                      .toString(),
                                                                );

                                                                // Check if the response has a successful status
                                                                if (response[
                                                                            "data"]
                                                                        [
                                                                        "status"] ==
                                                                    true) {
                                                                  Get.find<ListOfPostController>()
                                                                          .post
                                                                          .value =
                                                                      await snapshot
                                                                          .loadPost(
                                                                    '',
                                                                    limit,
                                                                    widget
                                                                        .apiurl,
                                                                  )!;

                                                                  Navigator.pop(context);
                                                                  Navigator.pop(context);
                                                                  Navigator.pop(context);
                                                                } else {
                                                                  Navigator.pop(context);
                                                                  Navigator.pop(context);
                                                                  Navigator.pop(context);

                                                                  Get.snackbar(
                                                                    "Failed",
                                                                    response["data"]["error_msg"] ?? "Something went wrong. Please contact administrator.",
                                                                    snackPosition: SnackPosition.BOTTOM,
                                                                    duration: Duration(seconds: 3),
                                                                  );
                                                                }
                                                              },
                                                              //     () async {
                                                              //   print(
                                                              //       ' report post url ${widget.apiurl} limit ${limit}, ');
                                                              //   showLoading(
                                                              //       context);
                                                              //   block(snapshot
                                                              //           .post
                                                              //           .value
                                                              //           .data!
                                                              //           .postDetails!
                                                              //           .posts![
                                                              //               index]!
                                                              //           .userDetails!
                                                              //           .userId
                                                              //           .toString())
                                                              //       .then(
                                                              //           (value) async {
                                                              //     if (value[
                                                              //             "data"]
                                                              //         [
                                                              //         "status"]) {
                                                              //       Get.find<ListOfPostController>()
                                                              //               .post
                                                              //               .value =
                                                              //           (await snapshot.loadPost(
                                                              //               '',
                                                              //               limit,
                                                              //               widget.apiurl))!;
                                                              //
                                                              //       Navigator.pop(
                                                              //           context);
                                                              //       Navigator.pop(
                                                              //           context);
                                                              //       Navigator.pop(
                                                              //           context);
                                                              //     }
                                                              //   });
                                                              // },
                                                              child: Text(
                                                                  'Report '))
                                                        ],
                                                      );
                                                    });
                                              },
                                              child: Row(
                                                children: [
                                                  Icon(Icons.warning),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text('Report post'),
                                                ],
                                              ),
                                            )),
                                            PopupMenuItem(
                                                child: TextButton(
                                              onPressed: () {
                                                showDialog(
                                                    context: context,
                                                    builder: (context) {
                                                      return AlertDialog(
                                                        title: Text(
                                                          'Hide this content?',
                                                          style: TextStyle(
                                                              fontSize: 16),
                                                        ),
                                                        actions: [
                                                          TextButton(
                                                              onPressed: () {
                                                                Navigator.pop(
                                                                    context);
                                                                Navigator.pop(
                                                                    context);
                                                              },
                                                              child: Text(
                                                                  'cancel')),
                                                          TextButton(
                                                              onPressed:
                                                                  () async {
                                                                print(
                                                                    'url ${widget.apiurl} limit $limit');
                                                                showLoading(
                                                                    context); // Show loading spinner
                                                                try {
                                                                  var response =
                                                                      await block(
                                                                    snapshot
                                                                        .post
                                                                        .value
                                                                        .data!
                                                                        .postDetails!
                                                                        .posts![
                                                                            index]!
                                                                        .userDetails!
                                                                        .userId
                                                                        .toString(),
                                                                  );
                                                                  if (response[
                                                                              "data"]
                                                                          [
                                                                          "status"] ==
                                                                      true) {
                                                                    Get.find<ListOfPostController>()
                                                                            .post
                                                                            .value =
                                                                        await snapshot
                                                                            .loadPost(
                                                                      '',
                                                                      limit,
                                                                      widget
                                                                          .apiurl,
                                                                    )!;
                                                                    print(
                                                                        'url ${widget.apiurl} limit $limit');
                                                                    Navigator.pop(
                                                                        context);
                                                                    Navigator.pop(
                                                                        context);
                                                                    Navigator.pop(
                                                                        context);
                                                                    // Get.snackbar(
                                                                    //   "Hide Sucessfully",
                                                                    //   response["data"]["error_msg"] ?? "Something went wrong",
                                                                    //   snackPosition: SnackPosition.BOTTOM,
                                                                    // );
                                                                  } else {
                                                                    Navigator.pop(
                                                                        context);
                                                                    Navigator.pop(
                                                                        context);
                                                                    Navigator.pop(
                                                                        context);
                                                                    // Show Snackbar if status is false
                                                                    Get.snackbar(
                                                                      "Failed",
                                                                      response["data"]
                                                                              [
                                                                              "error_msg"] ??
                                                                          "Something went wrong",
                                                                      snackPosition:
                                                                          SnackPosition
                                                                              .BOTTOM,
                                                                    );
                                                                  }
                                                                } catch (e) {
                                                                  Navigator.pop(
                                                                      context);
                                                                  Navigator.pop(
                                                                      context);
                                                                  Navigator.pop(
                                                                      context);
                                                                  Get.snackbar(
                                                                    "Error",
                                                                    "An error occurred. Please try again.",
                                                                    snackPosition:
                                                                        SnackPosition
                                                                            .BOTTOM,
                                                                  );
                                                                }
                                                              },
                                                              // onPressed:
                                                              //     () async {
                                                              //   showLoading(
                                                              //       context);
                                                              //   block(snapshot
                                                              //           .post
                                                              //           .value
                                                              //           .data!
                                                              //           .postDetails!
                                                              //           .posts![
                                                              //               index]!
                                                              //           .userDetails!
                                                              //           .userId
                                                              //           .toString())
                                                              //       .then(
                                                              //           (value) async {
                                                              //     if (value[
                                                              //             "data"]
                                                              //         [
                                                              //         "status"]) {
                                                              //       Get.find<ListOfPostController>()
                                                              //               .post
                                                              //               .value =
                                                              //           (await snapshot.loadPost(
                                                              //               '',
                                                              //               limit,
                                                              //               widget.apiurl))!;
                                                              //       print(
                                                              //           'url ${widget.apiurl} limit ${limit}');
                                                              //       Navigator.pop(
                                                              //           context);
                                                              //       Navigator.pop(
                                                              //           context);
                                                              //       Navigator.pop(
                                                              //           context);
                                                              //     }
                                                              //   });
                                                              // },
                                                              child: const Text(
                                                                  'Hide'))
                                                        ],
                                                      );
                                                    });
                                              },
                                              child: const Row(
                                                children: [
                                                  Icon(Icons
                                                      .remove_red_eye_outlined),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text('Hide post'),
                                                ],
                                              ),
                                            ))
                                          ]),
                        ),
                        snapshot.post.value.data!.postDetails!.posts![index]!
                                    .image!.isEmpty &&
                                snapshot.post.value.data!.postDetails!
                                    .posts![index]!.video!.isEmpty
                            ? Container()
                            : SizedBox(
                                height: Get.height * 0.30,
                                width: Get.width * 0.95,
                                // child: snapshot.post.value.data!.postDetails!
                                //             .posts![index]!.image!.isEmpty &&
                                //         snapshot.post.value.data!.postDetails!
                                //             .posts![index]!.video!.isEmpty
                                //     ?
                                //  ClipRRect(
                                //     borderRadius: BorderRadius.circular(15),
                                //     child: GestureDetector(
                                //       onTap: () {
                                //         showDialog(
                                //             context: context,
                                //             builder: (context) {
                                //               return SizedBox(
                                //                 height: Get.height,
                                //                 width: Get.width,
                                //                 child: video.SinglePostView(
                                //                     postId: snapshot
                                //                         .post
                                //                         .value
                                //                         .data!
                                //                         .postDetails!
                                //                         .posts![index]!
                                //                         .postId
                                //                         .toString()),
                                //               );
                                //             }).then((value) async {
                                //           Get.find<ListOfPostController>()
                                //               .post
                                //               .value = await Get.find<
                                //                   ListOfPostController>()
                                //               .loadPost(
                                //                   '', limit, widget.apiurl);
                                //         });

                                //         // Get.to(() => HomePostView(
                                //         //   index: index,
                                //         //   limit: limit,
                                //         //   apiurl: widget.apiurl,
                                //         // ));
                                //       },
                                //       // child: Placeholder(
                                //       //   fallbackHeight: 50,
                                //       //   fallbackWidth: 300,
                                //       // ),
                                //       // child: Image.network(
                                //       //   'http://upcwapi.graspsoftwaresolutions.com/public/images/user.png',
                                //       //   fit: BoxFit.cover,
                                //       // ),
                                //     ),
                                //   )
                                child: CustomCarouselSlider(
                                  items: snapshot.post.value.data!.postDetails!
                                          .posts![index]!.image!
                                          .map((i) {
                                        return Builder(
                                          builder: (BuildContext context) {
                                            return Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 8.0, right: 8.0),
                                              child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  child: GestureDetector(
                                                      onTap: () {
                                                        postViewCount(snapshot
                                                            .post
                                                            .value
                                                            .data!
                                                            .postDetails!
                                                            .posts![index]!
                                                            .postId
                                                            .toString());
                                                        showDialog(
                                                            context: context,
                                                            builder: (context) {
                                                              return SizedBox(
                                                                height:
                                                                    Get.height,
                                                                width:
                                                                    Get.width,
                                                                child: video.SinglePostView(
                                                                    postId: snapshot
                                                                        .post
                                                                        .value
                                                                        .data!
                                                                        .postDetails!
                                                                        .posts![
                                                                            index]!
                                                                        .postId
                                                                        .toString()),
                                                              );
                                                            }).then((value) async {
                                                          Get.find<
                                                                  ListOfPostController>()
                                                              .post
                                                              .value = await Get
                                                                  .find<
                                                                      ListOfPostController>()
                                                              .loadPost(
                                                                  '',
                                                                  limit,
                                                                  widget
                                                                      .apiurl);
                                                        });
                                                        // Get.to(() => HomePostView(
                                                        //   index: index,
                                                        //   limit: limit,
                                                        //   apiurl: widget.apiurl,
                                                        // ));
                                                      },
                                                      child: Image.network(
                                                        i,
                                                        fit: BoxFit.fitWidth,
                                                        width: Get.width * 0.95,
                                                        loadingBuilder:
                                                            (context, widget,
                                                                event) {
                                                          if (event
                                                                  ?.expectedTotalBytes ==
                                                              event
                                                                  ?.cumulativeBytesLoaded) {
                                                            return Image
                                                                .network(
                                                              i,
                                                              fit: BoxFit
                                                                  .fitWidth,
                                                              width: Get.width *
                                                                  0.95,
                                                            );
                                                          } else {
                                                            return CustomProgressIndicator();
                                                          }
                                                        },
                                                      ))),
                                            );
                                          },
                                        );
                                      }).toList() +
                                      snapshot.post.value.data!.postDetails!
                                          .posts![index]!.video!
                                          .map((i) {
                                        return Builder(
                                          builder: (BuildContext context) {
                                            return Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  child: GestureDetector(

                                                      // onTap: () {
                                                      //   showMyDialog(context,null,post.post.value.data!.postDetails!
                                                      //       .posts![widget.index]!.image?.map((e) => e.toString()).toList()
                                                      //   );
                                                      // },
                                                      onTap: () {
                                                        postViewCount(snapshot
                                                            .post
                                                            .value
                                                            .data!
                                                            .postDetails!
                                                            .posts![index]!
                                                            .postId
                                                            .toString());
                                                      },
                                                      child: video.VideoApp(
                                                        url: i.toString(),
                                                      ))),
                                            );
                                          },
                                        );
                                      }).toList(),
                                ),
                              ),
                        ButtonBar(
                          buttonHeight: 5,
                          buttonMinWidth: 3,
                          alignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 8,
                            ),
                            // SizedBox(
                            //   width: Get.width * 0.02,
                            // ),
                            Row(
                              children: [
                                GestureDetector(
                                  child: LikeButton(
                                    isLiked: snapshot
                                                .post
                                                .value
                                                .data!
                                                .postDetails!
                                                .posts![index]!
                                                .isLiked ==
                                            1
                                        ? true
                                        : false,
                                    onTap: (value) async {
                                      customLoading(context);

                                      var data = await snapshot
                                          .postLike(
                                              snapshot
                                                          .post
                                                          .value
                                                          .data
                                                          ?.postDetails
                                                          ?.posts![index]
                                                          ?.isLiked ==
                                                      1
                                                  ? 0
                                                  : 1,
                                              snapshot
                                                  .post
                                                  .value
                                                  .data!
                                                  .postDetails!
                                                  .posts![index]!
                                                  .postId!
                                                  .toInt()!,
                                              Get.find<SessionController>()
                                                  .session
                                                  .value
                                                  .data!
                                                  .userId!)
                                          .then((data) {
                                        if (data["message"] ==
                                            "post like inserted.") {
                                          setState(() {
                                            snapshot
                                                .post
                                                .value
                                                .data!
                                                .postDetails!
                                                .posts![index]!
                                                .likeCount = snapshot
                                                    .post
                                                    .value
                                                    .data!
                                                    .postDetails!
                                                    .posts![index]!
                                                    .likeCount! +
                                                1;
                                            snapshot
                                                .post
                                                .value
                                                .data!
                                                .postDetails!
                                                .posts![index]!
                                                .isLiked = 1;
                                          });
                                        }
                                        if (data["message"] ==
                                            "post like deleted.") {
                                          setState(() {
                                            snapshot
                                                .post
                                                .value
                                                .data!
                                                .postDetails!
                                                .posts![index]!
                                                .likeCount = snapshot
                                                    .post
                                                    .value
                                                    .data!
                                                    .postDetails!
                                                    .posts![index]!
                                                    .likeCount! -
                                                1;
                                            snapshot
                                                .post
                                                .value
                                                .data!
                                                .postDetails!
                                                .posts![index]!
                                                .isLiked = 0;
                                          });
                                        }
                                        Navigator.of(context).pop();
                                      });

                                      // snapshot.post.value= await snapshot.loadPost('',limit,)!;

                                      // Navigator.of(context).pop();
                                    },
                                    size: 20,
                                  ),
                                ),
                                Text(snapshot.post.value.data!.postDetails
                                        ?.posts![index]?.likeCount
                                        .toString() ??
                                    ''),
                              ],
                            ),
                            SizedBox(
                              width: 8,
                            ),
                            Row(
                              children: [
                                InkWell(
                                    onTap: () {
                                      showDialog(
                                          context: context,
                                          builder: (context) {
                                            return SizedBox(
                                              height: Get.height,
                                              width: Get.width,
                                              child: video.SinglePostView(
                                                  postId: snapshot
                                                      .post
                                                      .value
                                                      .data!
                                                      .postDetails!
                                                      .posts![index]!
                                                      .postId
                                                      .toString()),
                                            );
                                          }).then((value) async {
                                        Get.find<ListOfPostController>()
                                            .post
                                            .value = await Get.find<
                                                ListOfPostController>()
                                            .loadPost('', limit, widget.apiurl);
                                      });
                                      // Get.to(() => HomePostView(
                                      //       index: index,
                                      //   limit: limit,
                                      //   apiurl: widget.apiurl,
                                      //     ));
                                    },
                                    child: Icon(
                                      Icons.comment_rounded,
                                      size: 20,
                                    )),
                                SizedBox(
                                  width: 8,
                                ),
                                Text(snapshot.post.value.data!.postDetails
                                        ?.posts![index]?.commentCount
                                        .toString() ??
                                    ''),
                              ],
                            ),
                            SizedBox(
                              width: 8,
                            ),
                            Row(
                              children: [
                                Icon(Icons.remove_red_eye),
                                SizedBox(
                                  width: 8,
                                ),
                                // FutureBuilder<SinglePostViewModel>(
                                //     future: viewCountPostGetFromSinglePost(snapshot.post.value.data!.postDetails!.posts![index]!.postId.toString()),
                                //     builder: (context, snapshot) {
                                //       return Text(snapshot.data!.data.postDetails.views.toString());
                                //     }),
                                FutureBuilder<SinglePostViewModel>(
                                    future: viewCountPostGetFromSinglePost(
                                        snapshot.post.value.data!.postDetails!
                                            .posts![index]!.postId
                                            .toString()),
                                    builder: (context, snapshot) {
                                      if (snapshot.connectionState ==
                                          ConnectionState.waiting) {
                                        return const Text("0");
                                        // return Container(
                                        //   height: 20,
                                        //   width: 20,
                                        //   child: CircularProgressIndicator(
                                        //     color: Colors.grey,
                                        //   ),
                                        // );
                                      } else if (snapshot.connectionState ==
                                          ConnectionState.done) {
                                        if (snapshot.hasError) {
                                          return Text('0');
                                        } else {
                                          return Text(snapshot
                                              .data!.data.postDetails.views
                                              .toString());
                                        }
                                      } else {
                                        return Text('0');
                                      }
                                    }),
                              ],
                            ),

                            if (Get.find<SessionController>()
                                    .session
                                    .value
                                    .data!
                                    .role ==
                                1)
                              PopupMenuButton(
                                  itemBuilder: (itemBuilder) => [
                                        PopupMenuItem(
                                            child: TextButton(
                                          onPressed: () {
                                            Get.to(() => PostCreatePage(
                                                  isEdit: true,
                                                  urls: snapshot
                                                      .post
                                                      .value
                                                      ?.data
                                                      ?.postDetails
                                                      ?.posts![index]
                                                      ?.image,
                                                  content: snapshot
                                                      .post
                                                      .value
                                                      ?.data
                                                      ?.postDetails
                                                      ?.posts![index]
                                                      ?.content,
                                                  title: snapshot
                                                      .post
                                                      .value
                                                      ?.data
                                                      ?.postDetails
                                                      ?.posts![index]
                                                      ?.title,
                                                  postId: snapshot
                                                      .post
                                                      .value
                                                      ?.data
                                                      ?.postDetails
                                                      ?.posts![index]
                                                      ?.postId
                                                      .toString(),
                                                ));
                                          },
                                          child: Text('Edit'),
                                        )),
                                        PopupMenuItem(
                                            child: TextButton(
                                          onPressed: () {
                                            showDialog(
                                                context: context,
                                                builder: (context) {
                                                  return AlertDialog(
                                                    title: Text(
                                                        'Are you sure to delete this post'),
                                                    actions: [
                                                      TextButton(
                                                          onPressed: () {
                                                            Navigator.pop(
                                                                context);
                                                            Navigator.pop(
                                                                context);
                                                          },
                                                          child:
                                                              Text('cancel')),
                                                      TextButton(
                                                          onPressed: () async {
                                                            showLoading(
                                                                context);
                                                            deleteMyPost(snapshot
                                                                        .post
                                                                        .value
                                                                        ?.data
                                                                        ?.postDetails
                                                                        ?.posts![
                                                                            index]
                                                                        ?.postId
                                                                        .toString() ??
                                                                    '')
                                                                .then(
                                                                    (value) async {
                                                              if (value["data"]
                                                                  ["status"]) {
                                                                Get.find<ListOfPostController>()
                                                                        .post
                                                                        .value =
                                                                    (await snapshot.loadPost(
                                                                        '',
                                                                        limit,
                                                                        widget
                                                                            .apiurl))!;

                                                                Navigator.pop(
                                                                    context);
                                                                Navigator.pop(
                                                                    context);
                                                                Navigator.pop(
                                                                    context);
                                                              }
                                                            });
                                                          },
                                                          child: Text('Delete'))
                                                    ],
                                                  );
                                                });
                                          },
                                          child: Text('Delete'),
                                        ))
                                      ])
                            else
                              Text('')
                          ],
                        ),
                        (snapshot.post.value.data!.postDetails?.posts![index]!
                                        .content!
                                        .contains("http") ==
                                    true ||
                                snapshot.post.value.data!.postDetails
                                        ?.posts![index]!.content!
                                        .contains("https") ==
                                    true)
                            ? TextButton(
                                onPressed: () {
                                  _launchInBrowser(Uri.parse(
                                      "${snapshot.post.value.data!.postDetails?.posts![index]?.content}"));

                                  // launchUrlString(" ${snapshot.post.value.data!.postDetails?.posts![index]?.content} ");
                                },
                                child: Align(
                                    alignment: Alignment.bottomLeft,
                                    child: ReadMoreText(
                                      ' ${snapshot.post.value.data!.postDetails?.posts![index]?.content} ',
                                      textAlign: TextAlign.start,
                                      // trimLines: 2,

                                      trimLength: 80,
                                      trimMode: TrimMode.Line,
                                      trimCollapsedText: 'Show more',
                                      // trimExpandedText: 'Show less',
                                      colorClickableText: Colors.grey,

                                      moreStyle: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.grey),
                                      lessStyle: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.grey),
                                    )))
                            //  Linkify(
                            //     onOpen: (link) async {
                            //       if (await canLaunch(link.url)) {
                            //         await launch(link.url);
                            //       } else {
                            //         throw 'Could not launch $link';
                            //       }
                            //     },
                            //     text:
                            //         ' ${snapshot.post.value.data!.postDetails?.posts![index]?.content} ' ??
                            //             '',
                            //   )
                            : Align(
                                alignment: Alignment.bottomLeft,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 12.0),
                                  child: ReadMoreText(
                                    // '${snapshot.post.value?.data?.postDetails?.posts![index]?.userDetails!.name.toString() ?? ''}:
                                    ' ${snapshot.post.value.data!.postDetails?.posts![index]?.content} ' ??
                                        '',
                                    textAlign: TextAlign.start,
                                    // trimLines: 2,

                                    trimLength: 80,
                                    trimMode: TrimMode.Line,
                                    trimCollapsedText: 'Show more',
                                    // trimExpandedText: 'Show less',
                                    colorClickableText: Colors.grey,

                                    moreStyle: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.grey),
                                    lessStyle: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.grey),
                                  ),
                                ),
                              ),
                      ],
                    ),
                  ),
                );
              },
            );
          }

              // if (snapshot.post.value.data == null ||
              //     snapshot.post.value.data == 0) {
              //   if ( widget.isMember ==true ) {
              //     return const Center(
              //       child: Text('No posts found'),
              //     );
              //   } else {
              //     // If not a member, show "No posts"
              //     return const Center(
              //       child: CustomProgressIndicator(),
              //     );
              //   }
              //   return const Center(
              //      child: Text('No posts'),
              //   //  child: CircularProgressIndicator(),
              //   );
              // } else {
              //   return const Center(
              //     child: CustomProgressIndicator(),
              //   );
              // }
              )),
    );
  }
}

class CustomCarouselSlider extends StatefulWidget {
  const CustomCarouselSlider({
    super.key,
    this.items,
  });

  final List<Widget>? items;

  @override
  State<CustomCarouselSlider> createState() => _CustomCarouselSliderState();
}

class _CustomCarouselSliderState extends State<CustomCarouselSlider> {
  int _myIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        CarouselSlider(
            options: CarouselOptions(
                height: 300.0,
                viewportFraction: 1,
                enableInfiniteScroll: false,
                disableCenter: false,
                onPageChanged: (value, _) {
                  setState(() {
                    _myIndex = value;
                  });
                }),
            items: widget.items),
        Align(
          alignment: Alignment.bottomCenter,
          child: CarouselIndicator(
            activeColor: Colors.red,
            color: Colors.grey,
            count: widget.items!.length == 0 ? 1 : widget.items!.length,
            index: _myIndex,
          ),
        ),
      ],
    );
  }
}

Future<void> showMyDialog(BuildContext context, String url) async {
  return showDialog<void>(
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) {
      return Stack(
        children: [
          SizedBox(
              width: Get.width,
              height: Get.height,
              child: PhotoView(
                imageProvider: NetworkImage(url),
              )),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('Close')),
          )
        ],
      );
    },
  );
}

Future<void> showMyDialog2(BuildContext context) async {
  return showDialog<void>(
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        content: SingleChildScrollView(
          child: ListBody(
            mainAxis: Axis.horizontal,
            children: const <Widget>[],
          ),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text('Approve'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}

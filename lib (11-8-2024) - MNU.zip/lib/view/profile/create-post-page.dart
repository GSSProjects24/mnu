import 'dart:convert';
import 'dart:io';

import 'package:badges/badges.dart' as badges;
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/post_controller.dart';
import '../../controllers/sessioncontroller.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

import '../../theme/myfonts.dart';
import '../admin/admin-post-view.dart';
import '../auth/landing-page.dart';
import '../widgets/custom_loading.dart';

class PostCreatePage extends StatefulWidget {
  const PostCreatePage(
      {Key? key,
      required this.isEdit,
      this.urls,
      this.title,
      this.content,
      this.postId})
      : super(key: key);

  final bool isEdit;
  final List<dynamic>? urls;
  final String? title;
  final String? content;
  final String? postId;

  @override
  State<PostCreatePage> createState() => _PostCreatePageState();
}

class _PostCreatePageState extends State<PostCreatePage> {
  TextEditingController content = TextEditingController();
  TextEditingController title = TextEditingController();

  Future<Map<String, dynamic>> createPost(
      {required List<String?> images,
      required List<String?> videos,
      String? Title,
      String? Content}) async {
    var body = {
      "user_id":
          Get.find<SessionController>().session.value.data?.userId.toString(),
      "image": images,
      "video": videos,
      "content": Content ?? '',
      "title": Title ?? ''
    };
    print(Get.find<SessionController>().session.value.data?.userId);
    final response = await http.put(
        headers: {"Content-Type": "application/json"},
        Uri.parse('http://mnuapi.graspsoftwaresolutions.com/api_post'),
        body: jsonEncode(body));
    print(response.body);

    debugPrint(jsonEncode(body));

    if (response.statusCode == 200) {
      print(response.body);
      return jsonDecode(response.body);
    } else {
      print(response.body);
      throw Exception('Failed to load data');
    }
  }

  Future<Map<String, dynamic>> editPost(
      {required List<String?> images,
      required List<String?> videos,
      String? Title,
      String? Content,
      String? postId}) async {
    var body = {
      "post_id": postId,
      "user_id":
          Get.find<SessionController>().session.value.data?.userId.toString(),
      "image": images,
      "video": videos,
      "content": Content ?? '',
      "title": Title ?? ''
    };
    print(Get.find<SessionController>().session.value.data?.userId);
    final response = await http.put(
        headers: {"Content-Type": "application/json"},
        Uri.parse('http://mnuapi.graspsoftwaresolutions.com/api_post_edit'),
        body: jsonEncode(body));
    print('**********+' + response.body);
    if (response.statusCode == 200) {
      print(jsonEncode(body));
      print(response.body);
      return jsonDecode(response.body);
    } else {
      print(response.body);
      throw Exception('Failed to load data');
    }
  }

  // PostController postcotroller = PostController();
  final _formkey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    title.text = widget.title ?? '';
    content.text = widget.content ?? '';

    Get.put(PostController());

    widget.isEdit ? loadedit() : null;

    super.initState();
  }

  @override
  dispose() {
    Get.find<PostController>().dispose();
    super.dispose();
  }

  late VideoPlayerController _controller;

  loadedit() async {
    if (widget.isEdit && widget.urls != null) {
      List<String?> data = [];

      for (var dynamic in widget.urls!) {
        data.add(dynamic.toString());
      }

      await Get.find<PostController>().LoadNetworkImage(data!);

      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetX<PostController>(
        init: PostController(),
        initState: (value) async {
          // Get.find<PostController>().images=[];
          // Get.find<PostController>().memoryImage=[];
          // Get.find<PostController>().videos=[];
          // Get.find<PostController>().videoFiles=[];
          // Get.find<PostController>().files=[];
          // Get.find<PostController>().memoryVideo=[];
          widget.isEdit ? null : value.controller = PostController();
        },
        builder: (postcontroller) => Form(
              key: _formkey,
              child: Scaffold(
                appBar: AppBar(
                  title: Text(widget.isEdit ? 'Edit Your Post' : ''),
                  actions: [
                    // widget.isEdit
                    //     ? IconButton(
                    //         onPressed: () {},
                    //         icon: Icon(
                    //           Icons.delete,
                    //           color: Colors.red,
                    //         ))
                    //     : SizedBox(),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                          onPressed: () {
                            showModalBottomSheet(
                                isDismissible: true,
                                context: context,
                                builder: (context) {
                                  return SizedBox(
                                    height: Get.height * 0.13,
                                    width: Get.width,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: <Widget>[
                                        SizedBox(
                                          height: 100,
                                          child: Column(
                                            children: [
                                              IconButton(
                                                  onPressed: () async {
                                                    await postcontroller
                                                        .addFileFromCamera();
                                                  },
                                                  icon: Icon(
                                                    Icons.camera_alt,
                                                    size: 30,
                                                  )),
                                              Text('Camera')
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          height: 100,
                                          child: Column(
                                            children: [
                                              IconButton(
                                                  onPressed: () async {
                                                    await postcontroller
                                                        .addFiles();
                                                    setState(() {});
                                                  },
                                                  icon: Icon(
                                                    Icons.photo,
                                                    size: 30,
                                                  )),
                                              Text('Gallery')
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          height: 100,
                                          child: Column(
                                            children: [
                                              IconButton(
                                                  onPressed: () async {
                                                    await postcontroller
                                                        .addVideoFromCamera();
                                                  },
                                                  icon: Icon(
                                                    Icons.video_call_rounded,
                                                    size: 30,
                                                  )),
                                              Text('Video')
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          height: 100,
                                          child: Column(
                                            children: [
                                              IconButton(
                                                  onPressed: () async {
                                                    await postcontroller
                                                        .addVideoFromGallery();
                                                  },
                                                  icon: Icon(
                                                    Icons.file_copy,
                                                    size: 30,
                                                  )),
                                              Text('Video Gallery')
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                });
                          },
                          child: const SizedBox(
                            width: 80,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Center(child: Text('Add')),
                                Icon(Icons.camera)
                              ],
                            ),
                          )),
                    ),
                  ],
                ),
                body: SingleChildScrollView(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: CustomFormField(
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter some text';
                            }

                            return null;
                          },
                          controller: title,
                          labelText: 'Title',
                          obscureText: false,
                          maxlines: 1,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: CustomFormField(
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter some text';
                            }

                            return null;
                          },
                          controller: content,
                          labelText: 'Type your thoughts here',
                          obscureText: false,
                          maxlines: 4,
                        ),
                      ),
                      postcontroller.memoryImage.isEmpty
                          ? Container()
                          //     ? Icon(
                          //         Icons.photo,
                          //         size: 200,
                          //         color: Colors.grey.withOpacity(0.5),
                          //       )
                          //:
                          : Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SizedBox(
                                height: 170,
                                child: ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: postcontroller.memoryImage.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: badges.Badge(
                                          position:
                                              badges.BadgePosition.bottomEnd(),
                                          badgeStyle: badges.BadgeStyle(
                                              borderRadius:
                                                  BorderRadius.circular(4)),
                                          badgeContent: IconButton(
                                            onPressed: () {
                                              postcontroller.memoryImage
                                                  .removeAt(index);
                                              postcontroller.images
                                                  .removeAt(index);
                                              postcontroller.files
                                                  .removeAt(index);
                                              setState(() {});
                                            },
                                            icon: Icon(
                                              Icons.delete,
                                            ),
                                          ),
                                          child: SizedBox(
                                            height: 170,
                                            width: 150,
                                            child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                child: Image.memory(
                                                  postcontroller
                                                      .memoryImage[index],
                                                  fit: BoxFit.fill,
                                                )),
                                          )),
                                    );
                                  },
                                ),
                              ),
                            ),
                      postcontroller.memoryVideo.isEmpty
                          ? Container()
                          // ? Icon(
                          //     Icons.video_call,
                          //     size: 200,
                          //     color: Colors.grey.withOpacity(0.5),
                          //   )
                          // :
                          : Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SizedBox(
                                height: 170,
                                child: ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: postcontroller.memoryVideo.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: badges.Badge(
                                          position:
                                              badges.BadgePosition.bottomEnd(),
                                          badgeStyle: const badges.BadgeStyle(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(2))),
                                          badgeContent: IconButton(
                                            onPressed: () {
                                              postcontroller.memoryVideo
                                                  .removeAt(index);
                                              postcontroller.videos
                                                  .removeAt(index);
                                              postcontroller.videoFiles
                                                  .removeAt(index);
                                              setState(() {});
                                            },
                                            icon: const Icon(
                                              Icons.delete,
                                            ),
                                          ),
                                          child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              child: SizedBox(
                                                  height: 150,
                                                  width: 150,
                                                  child: VideoApp(
                                                    closedbodySmallFile:
                                                        postcontroller
                                                            .videoFiles[index],
                                                  )))),
                                    );
                                  },
                                ),
                              ),
                            ),
                      Text(
                        'Please upload the video  with less than 15 mb',
                        style: getText(context)
                            .bodySmall
                            ?.copyWith(color: Colors.grey.withOpacity(0.5)),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.all(8.0),
                      //   child: CustomFormField(
                      //     validator: (value) {
                      //       if (value == null || value.isEmpty) {
                      //         return 'Please enter some text';
                      //       }

                      //       return null;
                      //     },
                      //     controller: title,
                      //     labelText: 'Title',
                      //     obscureText: false,
                      //     maxlines: 1,
                      //   ),
                      // ),
                      // Padding(
                      //   padding: const EdgeInsets.all(8.0),
                      //   child: CustomFormField(
                      //     validator: (value) {
                      //       if (value == null || value.isEmpty) {
                      //         return 'Please enter some text';
                      //       }

                      //       return null;
                      //     },
                      //     controller: content,
                      //     labelText: 'Type your thoughts here',
                      //     obscureText: false,
                      //     maxlines: 4,
                      //   ),
                      // ),
                      SizedBox(
                        height: 40,
                      ),
                      ElevatedButton(
                          onPressed: () async {
                            if (_formkey.currentState!.validate()) {
                              List<String> images = postcontroller.images;
                              List<String> videos = postcontroller.videos;

                              if (widget.isEdit != true) {
                                showLoading(context);
                                await createPost(
                                        Content: content.text,
                                        images: images.toList(),
                                        Title: title.text,
                                        videos: videos)
                                    .then((data) {
                                  Navigator.pop(context);
                                  if (data["data"]["status"] == true) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                            content: Text(data["message"])));

                                    Get.off(() => const LandingPage());
                                  }
                                  if (data["data"]["status"] == false) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                            content: Text(data["message"])));

                                    Get.off(() => const LandingPage());
                                  } else {
                                    Navigator.pop(context);
                                  }
                                });

                                // Get.find<PostController>().dispose();
                              }
                              if (widget.isEdit) {
                                showLoading(context);
                                await editPost(
                                        Content: content.text,
                                        postId: widget.postId,
                                        images: images.toList(),
                                        Title: title.text,
                                        videos: videos.toList())
                                    .then((data) {
                                  if (data["data"]["status"] == true) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                            content: Text(data["message"])));
                                    Get.off(() => LandingPage());
                                  }
                                  if (data["data"]["status"] == false) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                            content: Text(data["message"])));
                                  }
                                });

                                // Get.find<PostController>().dispose();
                              }
                            }
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 30.0,
                            ),
                            child: Text(widget.isEdit ? 'Post' : 'Post'),
                          )),
                      SizedBox(
                        height: 50,
                      )
                    ],
                  ),
                ),
              ),
            ));
  }
}

Future<void> showMyDialog2(
    {required BuildContext context,
    void Function()? camera,
    void Function()? gallery}) async {
  return showDialog<void>(
    context: context,
    barrierDismissible: true, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        content: SizedBox(
          width: Get.width * 0.40,
          height: Get.height * 0.10,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              GestureDetector(
                  onTap: camera,
                  child: Image.network(
                    'https://cdn-icons-png.flaticon.com/512/3249/3249935.png',
                    height: 100,
                  )),
              GestureDetector(
                  onTap: gallery,
                  child: Image.network(
                    'https://cdn-icons-png.flaticon.com/512/7224/7224509.png',
                    height: 100,
                  )),
            ],
          ),
        ),
      );
    },
  );
}

class VideoApp extends StatefulWidget {
  const VideoApp({Key? key, required this.closedbodySmallFile})
      : super(key: key);

  final File closedbodySmallFile;

  @override
  _VideoAppState createState() => _VideoAppState();
}

class _VideoAppState extends State<VideoApp> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(widget.closedbodySmallFile,
        videoPlayerOptions: VideoPlayerOptions(
            // allowBackgroundPlayback: true,
            // mixWithOthers: true
            ))
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {});
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Center(
            child: _controller.value.isInitialized
                ? VideoPlayer(_controller)
                : Container(
                    color: Colors.black,
                  ),
          ),
          Center(
            child: IconButton(
              onPressed: () {
                setState(() {
                  _controller.value.isPlaying
                      ? _controller.pause()
                      : _controller.play();
                });
              },
              icon: Icon(
                _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
              ),
            ),
          )
        ],
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     setState(() {
      //       _controller.value.isPlaying
      //           ? _controller.pause()
      //           : _controller.play();
      //     });
      //   },
      //   child: Icon(
      //     _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
      //   ),
      // ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }
}
